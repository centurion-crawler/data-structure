#Chatroom 1.0
要在局域网实现通信只需要将Host 改成局域网中server所在的IP即可
###功能
help : 返回所有命令的使用
login nickname 登陆用户名
send message 发送信息
help function 返回function命令的使用方法

效果如图：
![client](./image/A.png "result1")
![server](./image/B.png "result2")